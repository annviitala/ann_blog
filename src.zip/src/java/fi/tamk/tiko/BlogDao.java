/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fi.tamk.tiko;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ann viitala
 */
@Stateless
public class BlogDao implements BlogDaoLocal {
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public void addPost(TheBlog blog) {
        em.persist(blog);
    }

    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void editPost(TheBlog blog) {
        em.merge(blog);
    }
    
    @Override
    public void deletePost(int post_id) {
        em.remove(getPost(post_id));
    }

    @Override
    public TheBlog getPost(int post_id) {
        return em.find(TheBlog.class, post_id);
    }

    @Override
    public List<TheBlog> getAllPost() {
        return em.createNamedQuery("TheBlog.getAll").getResultList();
    }

}
