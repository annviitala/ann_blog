/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fi.tamk.tiko;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ann viitala
 */
@Local
public interface BlogDaoLocal {

    void addPost(TheBlog blog);

    void editPost(TheBlog blog);

    TheBlog getPost(int post_id);

    List<TheBlog> getAllPost();

    void deletePost(int post_id);
    
}
