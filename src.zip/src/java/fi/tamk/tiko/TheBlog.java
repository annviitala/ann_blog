/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fi.tamk.tiko;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author ann viitala
 */
@Entity
@Table
@NamedQueries(@NamedQuery(name="TheBlog.getAll",query="SELECT e FROM TheBlog e"))
public class TheBlog implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column
    private int post_id;
    @Column
    private String post_title;
    @Column
    private String post_text;
    @Column
    private String post_author;

    public TheBlog(){}
    public TheBlog(int post_id, String post_title, String post_text, String post_author) {
        this.post_id = post_id;
        this.post_title = post_title;
        this.post_text = post_text;
        this.post_author = post_author;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public void setPost_title(String post_title) {
        this.post_title = post_title;
    }

    public void setPost_text(String post_text) {
        this.post_text = post_text;
    }

    public void setPost_author(String post_author) {
        this.post_author = post_author;
    }
       
    public int getPost_id() {
        return post_id;
    }

    public String getPost_title() {
        return post_title;
    }

    public String getPost_text() {
        return post_text;
    }

    public String getPost_author() {
        return post_author;
    }
    
    
}
